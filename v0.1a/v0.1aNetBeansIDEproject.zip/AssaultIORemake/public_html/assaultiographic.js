//Contents List (Top to Bottom);
//Time Calculations
//Reset Background
//Player Movement (WASD)
//Floor
//Player Rendering
//Weapon Toggle

//Variables --------- START

//Logic Vars
let devMode = true;
let mainMenu = false;

//Graphic Vars
let playerAvatar;
let crateBox;
let desertHutRoof;
let tankBody;
let modeToggle;

//PLAYER VARS ------ START
//Player Positioning
let playerX = 0;
let playerY = 0;
let playerSpeed = 5;
let playerMainWeapon = 0; //Weapon ID Stored
let playerSecondaryWeapon = 0; //Weapon ID Stored
let playerCurrentWeapon = 0; //0 Main 1 Secondary
let playerRotAngle = 0;
//PLAYER VARS ------- END

//Time Vars
let d1 = new Date();
let d2 = new Date();

//Object Vars
let allAssets = {}; //className : ID
let allAssetData = []; //ID ALWAYS Index 0 <<<<
let hitBoxes = [];
let loadedObjDict = {};
let loadedObjs = [];


//Variables --------- END

function preload() {
  playerAvatar = loadImage('assets/player.png');
  crateBox = loadImage('assets/crate.png');
  desertHutRoof = loadImage('assets/desert_building1_roof-1.png');
  tankBody = loadImage('assets/tankBase1.png');
}

function createObject(className){
    objID = allAssets[className];
    for (let iter=0;iter<allAssets.length;iter++){
        if (allAssets[iter][0] === objID){
            console.log(allAssets[iter][1]);
        }
    }
    
}

function toggleMode(){
    mainMenu = !mainMenu;
}

function setup() {
  createCanvas(800, 600);
  angleMode(DEGREES);
  if (devMode === true){
      modeToggle = createButton('Toggle Mode');
      modeToggle.position(0,0);
      modeToggle.mousePressed(toggleMode);
  }
}

function drawCrate(x, y){
    image(crateBox, x, y, 60, 60);
}
function drawHut(x, y){
    image(desertHutRoof, x, y, 300, 200);
}

//Main Menu
function drawMenu(){
    background(220);
    
}

function drawLogin(){
    background(220);
}

//Game Frame
function drawGameFrame(){
    //PreDraw Calculations
    //Change in time
    d2 = ((new Date())-d1)/100;
    d1 = new Date();
    
    //Set Scene
    background(220);
    image(playerAvatar, 0, 0, 50, 50);
    
    //Player Movement (WASD) ------- START
    if (keyIsDown(87)){
        playerY += playerSpeed*d2;
    };
    if (keyIsDown(65)){
        playerX += playerSpeed*d2;
    };
    if (keyIsDown(83)){
        playerY -= playerSpeed*d2;
    };
    if (keyIsDown(68)){
        playerX -= playerSpeed*d2;
    };
    //Player Movement (WASD) ------- END
    
    //Floor---
    fill(202, 141, 22);
    rect(50+playerX,50+playerY,600,500);
    
    
    //TEMPORARY Hardcoding map -------- START
    drawMap();
    //TEMPORARY Hardcoding map -------- END
    
    drawAvatar();
    image(tankBody, 0, 0, 125, 175);
}

function drawAvatar(){
    push();
    translate(400,300);
    //Player------------------START
    playerRotAngle = atan2(mouseY-300,mouseX-400);
    rotate(playerRotAngle);
    if (playerCurrentWeapon === 0){
        rotate(30);
        fill(255,0,0);
        rect(35,-35,25,10); //Left Hand
        rotate(-30);
        fill(128,128,128);
        rect(0,0,85, 10);
    } else {
        fill(128,128,128);
        rect(0,0,55, 10);
    };
    fill(255,0,0);
    rect(-25,-25, 50, 50); //Avatar
    rect(25,10,15,10); //Right Hand
    //Player------------------END
    pop();
}

function drawMap(){
    let x = 50+playerX;
    let y = 50+playerY;
    //Crate 1 Object
    drawCrate(x+10, y+10);
    //Crate 2 Object
    drawCrate(x+100, y+300);
    //Crate 3 Object
    drawCrate(x+450, y+75);
    //Hut Roof 1 Object
    drawHut(x+325, y+300);
}

function draw() {
    if (mainMenu === true){
        drawMenu();
    } else {
        drawGameFrame();
    }
    
    
}

function keyPressed(){
    if (key === 'q'){
        if (playerCurrentWeapon === 0){
            playerCurrentWeapon = 1;
        } else {
            playerCurrentWeapon = 0;
        }
    }
}